package com.sevgibasar.artbookjava;

public class Art {

    String name;
    int id;

    public Art(String name, int id) {
        this.name = name;
        this.id = id;
    }
}
