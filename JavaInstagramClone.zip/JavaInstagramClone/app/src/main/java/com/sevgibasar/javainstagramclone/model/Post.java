package com.sevgibasar.javainstagramclone.model;

public class Post {

    public String email;
    public String comment;
    public String downloadurl;


    public Post(String email, String comment, String downloadurl) {
        this.email = email;
        this.comment = comment;
        this.downloadurl = downloadurl;
    }
}
